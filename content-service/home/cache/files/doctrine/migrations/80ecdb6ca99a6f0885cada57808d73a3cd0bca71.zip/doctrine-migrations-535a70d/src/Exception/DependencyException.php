<?php

declare(strict_types=1);

namespace Doctrine\Migrations\Exception;

interface DependencyException extends MigrationException
{
}
